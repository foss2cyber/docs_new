# App templates

These examples have minimal content, but are intended to demonstrate how you
could structure layouts in your apps using dash-bootstrap-components.
